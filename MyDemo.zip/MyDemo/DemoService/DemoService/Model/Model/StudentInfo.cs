﻿using System.Runtime.Serialization;

namespace DemoService.Model
{
    [DataContract]
    public class StudentInfo
    {
        [DataMember]
        public string RollNumber { get; set; }

        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string State { get; set; }

        [DataMember]
        public string Address { get; set; }
    }
}
