﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoService.Model;
using DataAccess;

namespace Bussiness
{
    public class StudentBussiness
    {
        public string SaveStudentData(StudentInfo sInfo)
        {
            StudentDA stDA = new StudentDA();
            return stDA.SaveStudentData(sInfo);
        }
    }
}
