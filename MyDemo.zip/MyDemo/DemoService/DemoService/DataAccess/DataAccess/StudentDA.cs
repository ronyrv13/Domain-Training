﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DemoService.Model;
using System.Data;
using System.Data.SqlClient;

namespace DataAccess
{
    public class StudentDA
    {
        public string SaveStudentData(StudentInfo sInfo)
        {
            StringBuilder sbQuery = new StringBuilder();
            sbQuery.AppendFormat("INSERT INTO STUDENT(StudentUID, RollNumber,Name) VALUES (NEWID(), @RollNumber, @Name)");

            string connectionString = System.Configuration.ConfigurationManager.AppSettings["FIGMDHQIManagement"];
            using (SqlConnection _conn = new SqlConnection(connectionString))
            {
                _conn.Open();
                SqlCommand cmd = new SqlCommand(sbQuery.ToString(), _conn);
                cmd.Parameters.AddWithValue("@RollNumber", sInfo.RollNumber);
                cmd.Parameters.AddWithValue("@Name", sInfo.Name);

                int i = cmd.ExecuteNonQuery();
                return i.ToString();
            }
        }
    }
}
