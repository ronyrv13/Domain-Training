﻿//Generalized Modal Popup 

//How to use
//

/*
ShowMessage("Message to display", Is Modal(boolean), "Message type", "Vertical Position");

IsModal-True or False(Default)
Message type -Info,Success,Warning,Error,Simple(Default)
Vertical Alignment-Top(Default),bottom,middle.

*/


function __ShowMessage(Messagetext, IsModal, messageTyp, VerticalAlign) {
    //alert("hi");


    if (Messagetext == '' || Messagetext == null) {
        alert('Please set message text.');
        return;
    }
    $("#lblMsg").html(Messagetext);

    var Img = document.getElementById("imgInfo");
    var trBtn = document.getElementById("trBtn");
    var len = 0;

    $("#DvMsg").height("auto");
    //if (Messagetext.length > 30) {
    //    $("#DvMsg").width("220px");
    //}
    //else {
    //    $("#DvMsg").width("190px");
    //}
    var lenwidth = 0;
    Img.style.width = "16px";
    Img.style.height = "16px";

    messageTyp = messageTyp.toUpperCase()
    VerticalAlign = VerticalAlign.toUpperCase();
    //Message Type------------------------------------------------
    if (messageTyp == 'INFO') { //For Info Block Display

        $("#DvMsg").addClass("infoMsg");
        Img.src = "../content/images/info.ico";
        $("#btnOk").addClass("btnInfo");
    }

    else if (messageTyp == 'WARNING') { //For Warning Block Display
        HideMessage();
        $("#DvMsg").removeClass("SuccessMsg");
        $("#btnOk").removeClass("btnSuccess");
        $("#DvMsg").addClass("WarningMsg");
        Img.src = "../content/images/messagebox_warning.ico";
        if (Img.src.indexOf("PaperForm"))
            Img.src = Img.src.replace("PaperForm", "");
        $("#btnOk").addClass("btnWarning");

    }

    else if (messageTyp == 'SUCCESS') { //For Success Block Display
        HideMessage();
        $("#DvMsg").removeClass("WarningMsg");
        $("#btnOk").removeClass("btnWarning");
        $("#DvMsg").addClass("SuccessMsg");
        Img.src = "../content/images/SuccessFine.ico";
        $("#btnOk").addClass("btnSuccess");
        //trBtn.style.display = "none";

        //$("#dvshadow").show();
        //$("#DvMsg").show();
        //$("#DvMsg").fadeOut(2500);

    }
    else if (messageTyp == 'ERROR') { //For Error Block Display
        $("#DvMsg").addClass("ErrorMsg");
        $("#btnOk").addClass("btnError");
        // trBtn.style.display = "block";
        Img.src = "../content/images/no.ico";

        //$("#dvshadow").show();
        //$("#dvshadow").addClass("shadow");
        ////$("#DvMsg").show();
        //$("#DvMsg").fadeIn(1000);

        //$('#btnOk').click(function () {
        //    $("#DvMsg").hide();
        //    $("#dvshadow").hide();
        //});
    }
    else {

        $("#DvMsg").addClass("DefaultMsg");
        // Img.src = "images/no.ico";
        Img.style.display = 'none';
        IsModal = false;
    }

    //IsModal------------------------------
    if (IsModal == true) { //For Modal Pop up

        trBtn.style.display = "block";
        $("#dvshadow").show();
        $("#dvshadow").addClass("shadow");
        $("#DvMsg").fadeIn(1000);

        $('#btnOk').click(function () {
            $("#DvMsg").hide();
            $("#dvshadow").hide();
        });
    }
    else {
        $("#dvshadow").removeClass("shadow");
        trBtn.style.display = "none";

        $("#dvshadow").show();
        $("#DvMsg").show();

        var ua = window.navigator.userAgent;
        var old_ie = ua.indexOf('MSIE ');
        var new_ie = ua.indexOf('Trident/');

        if ((old_ie > -1) || (new_ie > -1)) {
            $("#DvMsg").delay(5000).fadeOut(500);
        }
        else {
            $("#DvMsg").delay(3000).fadeOut(1000);
        }

    }
    //Position------------------------------
    len = $("#DvMsg").height() + 10;
    lenwidth = $("#DvMsg").width();//+ 10


    $("#DvMsg").css(
         {
             "left": "50%",
             "margin-left": "-" + lenwidth / 2 + "px"//,
             // "left": X + "%"
         });

    if (VerticalAlign == 'BOTTOM' && VerticalAlign != null) {//bottom
        $("#DvMsg").css(
           {
               "bottom": "3%"//,
               // "margin-top": "-" + len / 2 + "px"//,
               // "left": X + "%"
           });
    }
    else if (VerticalAlign == 'MIDDLE' && VerticalAlign != null) {//Middle

        $("#DvMsg").css(
           {
               "top": "50%",
               "margin-top": "-" + len / 2 + "px"//,
               // "left": X + "%"
           });
    }
    else {
        $("#DvMsg").css(//Top
            {
                "top": "3%"//,
                // "margin-top": "-" + len / 2 + "px"//,
                // "left": X + "%"
            });
    }
}

//Updated By Rameshwar
function ShowMessage(Messagetext, IsModal, messageTyp, VerticalAlign) {

    if (Messagetext == '' || Messagetext == null) {
        alert('Please set message text.');
        return;
    }
    $("#lblMsg").html(Messagetext);
    $("#divInfo").removeAttr("class"); //Added
    $("#btnOk").removeAttr("class"); //Added
    $("#DvMsg").removeAttr("class");
    $("#DvMsg").height("auto");
    var lenwidth = 0;

    var trBtn = document.getElementById("trBtn");

    var len = 0;
    messageTyp = messageTyp.toUpperCase()
    VerticalAlign = VerticalAlign.toUpperCase();
    //Message Type------------------------------------------------
    if (messageTyp == 'INFO') { //For Info Block Display
        $("#DvMsg").addClass("infoMsg");
        $("#btnOk").addClass("btnInfo");
    }

    else if (messageTyp == 'WARNING') { //For Warning Block Display
        HideMessage();
        $("#DvMsg").removeClass("SuccessMsg");
        $("#btnOk").removeClass("btnSuccess");
        $("#DvMsg").addClass("WarningMsg");
        $("#btnOk").addClass("btnWarning");
        $("#divInfo").addClass("warninginfo"); //added 
    }

    else if (messageTyp == 'SUCCESS') { //For Success Block Display
        HideMessage();
        $("#DvMsg").removeClass("WarningMsg");
        $("#btnOk").removeClass("btnWarning");
        $("#DvMsg").addClass("SuccessMsg");
        $("#btnOk").addClass("btnSuccess");
        $("#divInfo").addClass("successinfo"); //added 
    }
    else if (messageTyp == 'ERROR') { //For Error Block Display
        $("#DvMsg").addClass("ErrorMsg");
        $("#btnOk").addClass("btnError");
        $("#divInfo").addClass("errorinfo"); //added 
        $('#btnOk').addClass("btnError");
    }
    else {

        $("#DvMsg").addClass("DefaultMsg");
        IsModal = false;
    }

    //IsModal------------------------------
    if (IsModal == true) { //For Modal Pop up

     trBtn.style.display = "block";

        $("#dvshadow").show();
        $("#dvshadow").addClass("shadow");
        $("#DvMsg").fadeIn(1000);

        $('#btnOk').click(function () {
            $("#DvMsg").hide();
            $("#dvshadow").hide();
        });
    }
    else {
        $("#dvshadow").removeClass("shadow");

          trBtn.style.display = "none";

        $("#dvshadow").show();
        $("#DvMsg").show();

        var ua = window.navigator.userAgent;
        var old_ie = ua.indexOf('MSIE ');
        var new_ie = ua.indexOf('Trident/');

        if ((old_ie > -1) || (new_ie > -1)) {
            $("#DvMsg").delay(5000).fadeOut(500);
        }
        else {
            $("#DvMsg").delay(3000).fadeOut(1000);
        }

    }
    //Position------------------------------
    len = $("#DvMsg").height() + 10;
    lenwidth = $("#DvMsg").width();//+ 10

    $("#DvMsg").css(
         {
             "left": "50%",
             "margin-left": "-" + lenwidth / 2 + "px"//,
             // "left": X + "%"
         });

    if (VerticalAlign == 'BOTTOM' && VerticalAlign != null) {//bottom
        $("#DvMsg").css(
           {
               "bottom": "3%"//,
           });
    }
    else if (VerticalAlign == 'MIDDLE' && VerticalAlign != null) {//Middle

        $("#DvMsg").css(
           {
               "top": "50%",
               "margin-top": "-" + len / 2 + "px"//,
           });
    }
    else {
        $("#DvMsg").css(//Top
            {
                "top": "3%"//,
            });
    }

}

function HideMessage() { //For Hiding Block on ok click
    $("#DvMsg").hide();
    $("#dvshadow").hide();
}
