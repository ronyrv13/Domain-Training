﻿
// This script use for on clicl add new and add more for patient information page
    function GEBI(sName) {
        return document.getElementById(sName);
    }
    function GEBC(sName)
    {
        return document.getElementsByClassName(sName);
    }

    function IsNumeric(keyCode)
    {
        if (keyCode > 31 && (keyCode < 48 || keyCode > 57))
            return false;
        else
            return true;
    }


    var defaultText = "First Middle Last";
    function WaterMark(txt, evt) {
        if (txt.value.length == 0 && evt.type == "blur") {
            txt.style.color = "Gray";
            txt.value = defaultText;
        }
        if (txt.value == defaultText && evt.type == "focus") {
            txt.style.color = "black";
            txt.value = "";
        }
    }


    function isTextKey(evt) {
        //alert('back space');
         var charCode = (evt.which) ? evt.which : event.keyCode
        //alert(charCode);
        if (charCode != 36 && charCode != 124 && charCode > 31 && (charCode < 48 || charCode > 57)) {
            return true;
        }
        if (charCode == 8) {
            //alert(charCode);
            return true;
        }

        return false;
    }


    function blockSpaceNumber(evt) {
        //alert('back space');
        var charCode = (evt.which) ? evt.which : event.keyCode
        keychar = String.fromCharCode(charCode);
        //alert(charCode);
        if (charCode != 36 && charCode != 124 && charCode > 31 && (charCode < 48 || charCode > 57) && keychar!=" ") {
            return true;
        }
        if (charCode == 8) {
            //alert(charCode);
            return true;
        }
        return false;
    }
        // for Patient Filling Auto suggest test box control

        //function Patient_Selected(sender, e) {
        //    var nameId = $get("<%# hdnNameId.ClientID %>");
        //    nameId.value = e.get_value();
        //    alert('nameId: ' +nameId)

        //    __doPostBack("btnPostPatientName", "");

        //    // to do refresh button and remove btnPostPatientName
        //}
        //function populate(sender, e) {
        //    if (sender._completionListElement.firstChild._value != null && sender._completionListElement.firstChild._value.toString().indexOf("00000000-0000-0000-0000-000000000000") != -1) {
        //        __doPostBack("btnPostPatientName", "");
        //    }
//}

    function blockSpaceTextBox(e) {
        var key;
        var isCtrl = false;
        var keychar;
        if (window.event) {
            key = e.keyCode;
            isCtrl = window.event.ctrlKey
        }
        else if (e.which) {
            key = e.which;
            isCtrl = e.ctrlKey;
        }
        keychar = String.fromCharCode(key);
        if (keychar == " ") {
            return false;
        }        
        return true;
    }

    function OnlyNumericValue(s, evt) {        
        var charCode = (evt.htmlEvent.which) ? evt.htmlEvent.which : event.keyCode
        if (charCode > 31 && (charCode < 48 || charCode > 57))
            _aspxPreventEvent(evt.htmlEvent);
    }


    function alphanumeric(inputtxt)  
    {   
        var letters = /^[A-Za-z0-9 _]+$/;
      
        if(inputtxt.match(letters))  
        {  
           
            return true;  
        }  
        else  
        {
           
            return false;  
        }  
    }

// set date control default get date set use this function if any where required
    function SetDefaultdate(s, e) {        
        var date = new Date();
        s.SetDate(date);
    }
   
    function blockSpaceEnterTextBox(e) {
        var key;
        var isCtrl = false;
        var keychar;
        if (window.event) {
            key = e.keyCode;
            isCtrl = window.event.ctrlKey
        }
        else if (e.which) {
            key = e.which;
            isCtrl = e.ctrlKey;
        }
        keychar = String.fromCharCode(key);
        if (keychar == " " || key == 13) {
            return false;
        }
        return true;
    }

    function ValiDateIPAddress(IPAddr) {
        var msg = "";

        var IP_result = /^[0-9A-Za-z/\[\].<>{}\\()_`^&*%$#|!~@;:"?+=-]+$/.test(IPAddr.trim());

        if (IPAddr != "")
            if (IP_result == false)
                msg += "Space( ),Comma(,) or Single quote(') is not allowed in IP address.";
        if (msg.length > 0) {
            ShowMessage(msg, true, "WARNING", "top");
            return false;
        }
        return true;

    }