var app = angular.module('m2', []);
app.controller('myCtrl', function($scope) {
  var technologies = [
      {
        name:"c#",likes:0,Dislikes:0},
       {name:"java",likes:0,Dislikes:0} ,
       { name:"Angular JS",likes:0,Dislikes:0},
       {name:"React JS",likes:0,Dislikes:0} ,
        {name:"MongoDB",likes:0,Dislikes:0},
      {name:"C++",likes:0,Dislikes:0}  

  ];
  $scope.technology = technologies;

  $scope.incrementlikes= function(technology){
      technology.likes++;
  }

  $scope.incrementdislikes= function(technology){
      technology.Dislikes++;
  }
});