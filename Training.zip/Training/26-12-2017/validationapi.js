$(document).ready(function()
{
    $("#contactform").validate({

        rules:{
                name:{
                     required:true,
                        minlength:8
                     },
            
                email:{
                    required:true,
                    email:true
                      },
                
                comments:{
                    required:true,
                    minlength:25
                }
             }

       })

});