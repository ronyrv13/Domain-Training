$(document).ready(function(){
     $('#contactform').submit(function(){
     
        var name= $("#name").val();
        var comment= $("#comments").val();
        var errormsgs = [];
        var mail= $("email").val();
        haserror= false;
       

                if(!name)
                {
                    haserror= true;
                    errormsgs.push("Name Required")
                }

                if(!comment)
                {
                    //alert("Hi");
                    haserror= true;
                    errormsgs.push("please give Comments")
                }

                if(!mail)
                {
                    //alert("Hi");
                    haserror= true;
                    errormsgs.push("Enter Email")
                }
                if(haserror)
                {
                    errormsgs.forEach(function(element){
                    document.getElementById("resulterror").innerHTML = errormsgs;
                    },this);   
                    return false;
                }

    });

});