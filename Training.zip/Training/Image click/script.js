var container = document.getElementById('imagecontainer');

container.addEventListener('mouseover', mouseOver);
container.addEventListener('mouseout', mouseOut);
container.addEventListener('click', changeimage);

function mouseOver()
{
    container.style.cursor='hand';
}

function mouseOut()
{
    container.style.cursor='default';

}

function changeimage(e)
{
    var imageurl =(e.target).src;
  if(typeof(imageurl)!=='undefined'){
   
    var image = document.getElementById('mainimage');
    image.src = imageurl;
  }
}




