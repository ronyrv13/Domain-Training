

var myapp = angular.module("myModule",[]).
controller("myControllerFun",function($scope)
{
      var Employees =[
    { Name:"Rony Varghese",Gender:"Male",Age:24,Salary:500000
    },
    {
 Name:"Sundar",Gender:"Male",Age:24,Salary:300000
    },
    { Name:"Mahesh Bondre",Gender:"Male",Age:24,Salary:400000
    },
    { Name:"Nikhil Singatkar",Gender:"Male",Age:24,Salary:40
    } 
    ];

    $scope.Employees=Employees;
    
    $scope.message= "Welcome to ANGULARJS";

});

    /*var ampp ={
        Name:"Rony",
        Gender:"Male",
        Age:24

    };
    
    $scope.ampp=ampp;*/


var directive = angular.module("m1",[]).
controller("c1",function($scope){

     var Employee =[
    { Name:"Rony Varghese",Gender:"Male",City:"ITARSI"
    ,Salary:500000
    },
    {
 Name:"Sundar",Gender:"Male",City:"Nagpur",Salary:300000
    },
    { Name:"Mahesh Bondre",Gender:"Male",City:"Pune",Salary:400000
    },
    { Name:"Nikhil Singatkar",Gender:"Male",City:"jalgaon",Salary:40
    } 
    ];
      $scope.Employee=Employee;



});

