var myApp= angular.module("myModule",[]).
controller("myController",function($scope){
    var Employee={
            Firstname:"Rony",
            Lastname:"Varghese",
            Gender:"Male"
    };
    $scope.Employee=Employee;

});
