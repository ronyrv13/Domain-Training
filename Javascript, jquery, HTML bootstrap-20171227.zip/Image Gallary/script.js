var container = document.getElementById('imageContainer');

container.addEventListener('mouseover', mouseOver);
container.addEventListener('mouseout', mouseOut);
container.addEventListener('click', changeImage);

function mouseOver() {
    container.style.cursor = 'hand';
}

function mouseOut() {
    container.style.cursor = 'default';
}

function changeImage(e) {
    var imageUrl = (e.target).src;
    if (!typeof(imageUrl)) {
        var image = document.getElementById('mainImage');
        image.src = imageUrl;
    }
}