function startclock() {
    var date = new Date();
    var hours = date.getHours();
    var minute = date.getMinutes();
    var seconde = date.getSeconds();
    var session = 'am';

    if (hours == 0)
        hours = 12;

    if (hours >= 12 && hours < 13)
        session = 'PM';

    if (hours >= 13) {
        hours = hours - 12;
        session = 'pm';
    }

    hours = hours < 10 ? "0" + hours : hours;
    minute = minute < 10 ? "0" + minute : minute;
    seconde = seconde < 10 ? "0" + seconde : seconde;

    var time = hours + ": " + minute + ":" + seconde + " " + session;

    var my = document.getElementById('myclock');
    my.innerHTML = time;

}
setInterval(startclock, 1000);