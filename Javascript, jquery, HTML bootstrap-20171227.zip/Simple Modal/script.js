var simplemodal = document.getElementById('simpleModal');
// get the button object
var btn = document.getElementById('modalBtn');
// get the object to close the modal
var close = document.getElementById('closebtn');

btn.addEventListener('click', openModal);
close.addEventListener('click', closeModal);
window.addEventListener('click', outsideclick);

function openModal() {
    simplemodal.style.display = 'block';
}

function closeModal() {
    simplemodal.style.display = 'none';
}

function outsideclick(e) {
    if (e.target == simplemodal)
        simplemodal.style.display = 'none';
}