$(document).ready(function() {
    $("#name").keypress(function(e) {
        //if the letter is not digit then display error and don't type anything
        if ((e.which >= 48 && e.which <= 57)) {
            //display error message
            $("#errmsg").html("Name can contain letters Only").show().fadeOut(1700);
            return false;
        }
    });
});