$(document).ready(function() {
    var rightImage = $('#chafa').attr('src');
    var leftImage = $('#rose').attr('src');

    $('#left').on('click', function() {
        $('#rose').attr('src', rightImage);
    });

    $('#right').on('click', function() {
        $('#chafa').attr('src', leftImage);
    });

    $('#swap').on('click', function() {
        var rightImage = $('#chafa').attr('src');
        var leftImage = $('#rose').attr('src');
        $('#chafa').attr('src', leftImage);
        $('#rose').attr('src', rightImage);
    });
});