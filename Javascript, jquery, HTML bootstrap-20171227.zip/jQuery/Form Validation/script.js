$(document).ready(function() {

    $("#contactForm").validate({
        rules: {
            name: {
                required: true,
                minlength: 6
            },
            email: {
                email: true
            }
        }
    });

    // $("#contactForm").submit(function() {

    //     var name = $("#name").val();
    //     var comments = $("#comments").val();
    //     $("#resultError").html(" ");

    //     var hasError = false;

    //     var errorMsgs = [];
    //     if (!name) {
    //         hasError = true;
    //         errorMsgs.push("Name is required");
    //     }

    //     if (!comments) {
    //         hasError = true;
    //         errorMsgs.push('No comments given');
    //     }
    //     if (hasError) {
    //         var str = ' <div class = "alert alert-danger" role = "alert"><span><b> Please Correct</b></span><ul>';
    //         errorMsgs.forEach(function(item) {
    //             str += '<li>' + item + '</li>';
    //         }, this);
    //         str += "</ul></div>'";
    //         $("#resultError").html(str);
    //         return false;

    //         //   var errorStr = '<div class = "alert alert-danger" role = "alert"><strong> Please correct: </strong><ul>';
    //         // $.each(ErrorMsgs, function(index, value) {
    //         //     errorStr += '<li>' + value + '</li>';
    //         // }, this);
    //         // errorStr += '</ul></div>';
    //         // $('#resultError').html(errorStr);
    //         // for (var i = 0, len = errorMsgs.length; i < len; i++)
    //         //     $("#resultError").append(errorMsgs[i]);
    //     }
    // });
});