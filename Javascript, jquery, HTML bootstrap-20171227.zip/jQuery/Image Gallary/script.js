$(document).ready(function() {
    $("#divContainer").on({
        mouseover: function() {
            $(this).css({
                'cursor': 'hand',
                'border-color': 'red'
            });
        },

        mouseout: function() {
            $(this).css({
                'cursor': 'default',
                'border-color': 'grey'
            });
        },

        click: function() {
            var imgUrl = $(this).attr('src');
            //$("#mainImg").attr('src', imgUrl);

            var effect = $("#selectImgEffect").val();
            var duration = $("#selectImgDuration").val() * 1000;


            if (effect == 'Fade') {
                $("#mainImg").fadeOut(duration, function() {
                    $(this).attr('src', imgUrl);
                }).fadeIn(duration);
            } else {
                $("#mainImg").slideUp(duration, function() {
                    $(this).attr('src', imgUrl);
                }).slideDown(duration);
            }
        }
    }, "img");

    var mainImg = $("body img:first");
    var height = parseInt(mainImg.attr('height'));
    var width = parseInt(mainImg.attr('width'));

    $("#btnEnlarge").click(function() {
        //alert("enlarge");
        height += 100;
        width += 100;

        mainImg.animate({
            'height': height,
            'width': width
        });
    });

    $("#btnShrink").click(function() {
        height -= 100;
        width -= 100;
        $("body img:first").animate({
            'height': height,
            'width': width
        });
    });
});