create database myDB;

-- How to create new table ?
-- SQL Language 

-- Person 
create table Tbl_person
(
 id int,
 firstname varchar(20),
 lastname varchar(20),
 [Address] varchar(30)
)

create table Tbl_person2
(
 id int,
 firstname varchar(20),
 lastname varchar(20),
 [Address] varchar(30)
)

-- add new column 
alter table tbl_person
add 
city varchar(10),
pincode int;


select *from Customer;
select Id, FirstName, LastName, City,Country, Phone from Customer;

-- drop column
alter table tbl_person
drop column pincode;

-- TCL statements
select *from Student;

begin transaction
delete from Student where rollno=4;

rollback
commit

