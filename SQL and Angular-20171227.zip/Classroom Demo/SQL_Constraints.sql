select *from Tbl_person;

insert into Tbl_person values
(1,'aa','bb','pune','baner'),
(2,'aa',null,'mumbai',null),
(3,'bb','cc',null,'baner');


insert into Tbl_person(id,firstname,lastname,city) 
values(4,'xyz','abc','xyz');

insert into Tbl_person(firstname,id,lastname) 
values('abcd',5,'xyz');

-- add constraints
-- Entity integrity rule :
-- Primary key 
alter table tbl_person
add constraint pk_person primary key(id);
-- NOT NULL constraint on ID column 

alter table tbl_person
alter column id int not null;

-- empty table
truncate table tbl_person

-- drop/delete  primary key
alter table tbl_person
drop PK__Tbl_pers__3213E83FF8412F7E;

alter table tbl_person
add primary key(id);

-- Firstname : not null

alter table tbl_person
alter column firstname varchar(20) not null;

-- default address ?
alter table tbl_person
add DEFAULT 'Pune' for [address];

select *from Tbl_person

--primary key = not null + unique

-- Foreign key 
-- EMP-DEPT : many to one
-- Emp : id,name,salary,dept_id(foreign key)
-- Dept : id,name,location
create table dept
(
  id int primary key,
  name varchar(20),
  location varchar(20)
)

create table emp
(
 id int primary key,
 name varchar(20),
 salary int,
 dept_id int foreign key references dept(id)
)

select * from dept;
select * from emp;

insert into emp(id,name,salary) values (3,'puja',43000);




