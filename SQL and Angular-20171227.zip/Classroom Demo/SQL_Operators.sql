-- SQL Operators 

select *from dept_backup2;

-- copy of dept table
select *into Dept_backup
from dept;

insert into Dept_backup2
select *from dept;

-- distinct : distinct/different values 
select *from Customer
--Display distinct cities from customer table
select distinct city from Customer;
-- Display FirstName,and Country of the customer without repeatation
select distinct country,FirstName from Customer;

--1. Display all Customers from the country of France,Spain,UK,canada and maxico
select *from Customer
where Country in('france','spain','uk','canada','maxico')
order by Country;

--2. Display all customers from customer table,except London City.
select *from Customer
where City <> 'london';

--3. Display all customer whose firstname is between 'A' to 'G'
select *from Customer
where FirstName between 'A' and 'G'
order by FirstName;

-- LIKE : pattern matching 
-- 1. select all customers with a FirstName starting with "a"
select *from Customer where FirstName like 'a%'
--	2. select all customers with a FirstName ending with "a"
select *from Customer where FirstName like '%a'
--	3. select all customers with a FirstName that have "or" in any position
select *from Customer where FirstName like '%or%'
--	4. select all customers with a FirstName that have "r" in the second position:
select *from Customer where FirstName like '_r%'
--	5. select all customers with a FirstName that starts with "a" and are at least 3 characters in length
    -- 'a__%'
--	6. select all customers with a FirstName that NOT starts with "a"
select *from Customer where FirstName not like 'a%'

-- Alias
select 
id as Customer_id,
firstname as Customer_FirstName,
lastname as Customer_LastName,
city from Customer;

select 
id  [Customer id],
firstname  'Customer FirstName',
lastname  'Customer LastName',
city from Customer;

select top 1 *from tblEmployee
order by Salary desc;


