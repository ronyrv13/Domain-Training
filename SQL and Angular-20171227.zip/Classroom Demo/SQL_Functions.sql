-- Built in functions in SQL

-- 1. Aggregate functions :


select *from Customer;

select COUNT(Id) as [Total Customer] from Customer;
select COUNT(distinct FirstName) as [Firstname count] from Customer;

--  Display avarage amount of Orders table.
select AVG(TotalAmount) as AvgAmount from Orders;
-- Display avarage amount of Orders table for the amount between 500 and 1000
select AVG(TotalAmount) as AvgAmount from Orders
where TotalAmount between 500 and 1000;

select *From Customer where city='london';

select city,country,COUNT(Id) from Customer
where City='london'
group by city,Country;

-- Display the sum of totalAmount of every customer who placed an order.
select *from Orders;
select sum(TotalAmount) "SUM",CustomerId from Orders
where CustomerId is not null group by CustomerId;

--  Display the count of orders placed for a praduct and productid must be between 1 to 5. [use OrderItem table]
select *from OrderItem
select count(OrderId),ProductId from OrderItem where ProductId between 1 and 5 group by ProductId;

--Write a SQL statement to lists the number of customers in each country, sorted high to low.
select country,COUNT(Id) [TotalCust] from Customer
group by Country
order by COUNT(Id)
-- List the number of customers in each country. Only include countries with more than 10 customers
select country,COUNT(Id) [TotalCust] from Customer
--where COUNT(Id) > 10
group by Country
having COUNT(Id) > 10
--Write a SQL statement to lists the number of customers in 'London' city,and name must starting from 'A'.
select FirstName,City,COUNT(Id) [TotalCust] from Customer
where City= 'london' and FirstName like 'a%'
group by Country,City,FirstName


select ISNULL(Salary,0) +100 as [updated salary] from tblEmployee;

select PI();
select ABS(-18)

-- FullName of customer
select FirstName+SPACE(4)+LastName as [Full Name]
from Customer

--Fullname is located at cityname
select FirstName+SPACE(3)+LastName+' is located at '+City from Customer

select CONCAT(firstname,SPACE(3),lastname,' is located at ',city) from Customer

select LEFT(FirstName,3),RIGHT(FirstName,3),LEN(FirstName) from Customer 

select REPLACE('Hello World','l','#');

-- Display FirstName of customer. [only first letter in upper case and other letters in lowercase]
select UPPER(LEFT(FirstName,1))+LOWER(RIGHT(FirstName,len(FirstName)-1)) from Customer;

select CONVERT(date,GETDATE());
select YEAR(GETDATE()) [Year],MONTH(GETDATE()) [Month],DAY('2017-11-01') [Day];

select DATENAME(MM,getdate());

-- Different date formats
select FORMAT(GETDATE(),'dd/MM/yyyy') as [date]; 	
--=> 04/12/2017
	select FORMAT(GETDATE(),'MM/dd/yy') as [date];		
--=> 12/04/17
	select FORMAT(GETDATE(),'dddd,MMMM,yy') as [date]; 	
--=> Monday,December,2017
	select FORMAT(GETDATE(),'MMMM,dd,yyyy') as [date]; 
--	=> December,04,2017
	select FORMAT(GETDATE(),'MMMM,dd,yyyy'+SPACE(5)+ 'hh:mm:ss tt') as [date];