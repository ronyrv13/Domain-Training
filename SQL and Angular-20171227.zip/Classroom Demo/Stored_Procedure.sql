-- Stored Procedure

--Write a stored procedure to select all data from Customer table.

create procedure usp_GetAllCustomer
as
	select *from Customer
go

-- How to call sp
exec usp_GetAllCustomer
execute usp_GetAllCustomer

sp_executesql usp_GetAllCustomer -- improve performance of query

-- How to create store procedure with input parameters ?
select *from tblEmployee

CREATE PROC usp_GetEmpByGenderAndDeptId
	@Gender nvarchar(10),
	@DeptId int
	AS		
	BEGIN
		Select Name,Gender,DepartmentId from tblEmployee
		where Gender=@Gender and DepartmentId=@DeptId
	END

exec usp_GetEmpByGenderAndDeptId 'feMale',3

-- How to create store procedure with output parameters ?
CREATE PROCEDURE uspGetEmployeeCountByGender
	@Gender nvarchar(20),
	@EmployeeCount int Output
	AS
	BEGIN
		SELECT @EmployeeCount = COUNT(Id) 
		FROM tblEmployee 
		WHERE Gender = @Gender
	END

select *from tblEmployee where Gender='male'

DECLARE @EmployeeTotal int
EXECUTE uspGetEmployeeCountByGender 'Male', @EmployeeTotal output
PRINT @EmployeeTotal


-- to see text of stored procedure 
sp_helptext uspGetEmployeeCountByGender
exec custproc

-- encrypted stored procedure
ALTER PROCEDURE uspGetEmployeeCountByGender
	@Gender nvarchar(20),
	@EmployeeCount int Output
	WITH ENCRYPTION
	AS
	BEGIN
		SELECT @EmployeeCount = COUNT(Id) 
		FROM tblEmployee 
		WHERE Gender = @Gender
	END