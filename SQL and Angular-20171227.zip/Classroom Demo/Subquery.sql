-- Subqueries in SQL
select *from tblEmployee;
-- Emp whose salary is greater than avg salary 

-- Non-correlated subquery
select id,name,salary from tblemployee where salary >(select AVG(salary)from tblEmployee)

--1. List products with order quantities greater than 100. [Use product and OrderItem table]
select *from Product
select *from OrderItem
-- =ANY = IN 
select productname from product where id =any
(select distinct productid from OrderItem where Quantity>100)

--2. Write a query to find the products that are not sold at least once. [Use tblProd and tblSales table]
select *from tblProd
select *from tblSales

select name from tblprod where id not in
(select distinct productid from tblSales)
--1. List all customers with their total number of orders. [Use customer and Orders table]
select *from Customer
select *from Orders

select Id,FirstName,LastName,
TotalOrders=(select COUNT(CustomerId)
			 from Orders 
			 where Customer.Id=Orders.CustomerId
			 group by CustomerId )
from Customer

--2. Write a query to retrieve the name and total quantity sold for each product.
--   [Use tblProd and tblSales table]
select *from tblProd
select *from tblSales

select Name,TotalQntySold=(select SUM(QuantitySold)
					 from tblSales
					 where tblProd.Id=tblSales.ProductId
					 group by productid)
from tblProd

-- using join
select name,ISNULL(sum(QuantitySold),0) [TotalQtySold]
from tblProd left join tblSales 
on tblProd.Id=tblSales.ProductId
group by tblSales.ProductId,Name;

select *from tblEmployee
select *from tblDepartment

-- Practice 
--1. List the Employees who earns same as a 'Tom'.

select Name from tblEmployee where Salary=(select Salary from tblEmployee where Name='Sam' ) and Name <> 'Sam'

--2. List the Employees who earns more than a average salary.


--3. What is second highest salary ? [ tblEmployee ]

select MAX(salary) from tblEmployee where Salary< (select MAX(salary) from tblEmployee )

--4. Who gets second highest salary ? [ tblEmployee ]
select name from tblEmployee where Salary=(
select MAX(salary) from tblEmployee where Salary< (select MAX(salary) from tblEmployee ))

--5. List the Employees whose DepartmentHead is 'Ron'.

select name from tblEmployee where DepartmentId=(select ID from tblDepartment where DepartmentHead='Ron')

--6. List the DepartmentHead-name and total number of employees working under them.

select departmentHead ,No_of_emp=
(select count(id) from tblEmployee where tblDepartment.ID=tblEmployee.DepartmentId 
group by DepartmentId )
from tblDepartment

