-- SQL JOINS

-- tblemployee and tbldepartment
select *from tblEmployee
select *from tblDepartment

-- Equi join
--Write a query to display Name,Gender,Salary and DepartmentName of an Employee.
select Name,Gender,Salary,DepartmentName
from tblEmployee,tblDepartment
where tblEmployee.DepartmentId=tblDepartment.ID;

-- inner join
select Name,Gender,Salary,DepartmentName
from tblEmployee inner join tblDepartment
on tblEmployee.DepartmentId=tblDepartment.ID;

-- List all the orders with product name,quantities and prices.[Use Orders,OrderItem and Product tables]
select *from Orders
select *from OrderItem
select *from Product

select CONVERT(date,OrderDate) as OrderDate ,OrderNumber,
ProductName,Quantity,ISNULL(oi.UnitPrice,0) as UnitPrice
from Orders o inner join OrderItem oi 
on o.Id=oi.OrderId
inner join Product p
on oi.ProductId=p.Id
order by UnitPrice

select tblEmployee.ID, Name,Salary,DepartmentName
from tblEmployee left join tblDepartment
on tblEmployee.DepartmentId=tblDepartment.ID

select tblEmployee.ID,Name,Salary,tblDepartment.id,DepartmentName
from tblEmployee right join tblDepartment
on tblEmployee.DepartmentId=tblDepartment.ID

--List all customers, whether they placed any order or not.[Use Customer and Orders table. LEFT JOIN]
select *from Customer
select *from Orders

select FirstName,LastName,City,OrderDate,OrderNumber
from Customer left join Orders
on Customer.Id=Orders.CustomerId

-- List the customers that have not placed orders. 

--Match customers that are from the same city and country [Customer table. SELF JOIN]
select 
c1.FirstName as FirstName1,c1.LastName as LastName1,
c2.FirstName as FirstName2,c2.LastName as LastName2,
c2.City,c2.Country
from Customer c1,Customer c2
where c1.Id <> c2.Id
and c1.City=c2.City and c1.Country=c2.Country
order by Country;

