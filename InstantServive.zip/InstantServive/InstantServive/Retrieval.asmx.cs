﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace InstantServive
{
    /// <summary>
    /// Summary description for Retrieval
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    // To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
     [System.Web.Script.Services.ScriptService]


    public class Retrieval : System.Web.Services.WebService
    {

        [WebMethod]
        public Employee GetId(int id)
        {
            Employee emp = new Employee();
            SqlConnection CON = new SqlConnection(ConfigurationManager.ConnectionStrings["figmd"].ConnectionString);
            CON.Open();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = CON;

            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "spGetEmployee11";

            cmd.Parameters.AddWithValue("@id", id);

            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                emp.GetId = reader.GetInt32(0);
                emp.GetName = reader.GetString(1);
                emp.Gender = reader.GetString(2);
            }
            return emp;
        }
    }
}
