﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace InstantServive
{
    public class Employee
    {

        public int GetId { get; set; }

        public string GetName { get; set;}

        public string Gender { get; set; }

    }
}